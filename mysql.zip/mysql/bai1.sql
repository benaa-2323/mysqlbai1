-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th1 13, 2020 lúc 11:56 AM
-- Phiên bản máy phục vụ: 10.4.11-MariaDB
-- Phiên bản PHP: 7.2.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `bai1`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `dangkycungcap`
--

CREATE TABLE `dangkycungcap` (
  `MaDKCC` char(20) NOT NULL,
  `MaNhaCC` char(10) NOT NULL,
  `maloaidv` char(10) NOT NULL,
  `dongxe` char(10) NOT NULL,
  `MaMp` char(10) NOT NULL,
  `ngaybatdaucungcap` int(11) DEFAULT NULL,
  `ngayketthuccungcap` int(11) DEFAULT NULL,
  `soluongxedangky` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `dangkycungcap`
--

INSERT INTO `dangkycungcap` (`MaDKCC`, `MaNhaCC`, `maloaidv`, `dongxe`, `MaMp`, `ngaybatdaucungcap`, `ngayketthuccungcap`, `soluongxedangky`) VALUES
('DK001', 'NCC001', 'DV01', 'Hiace', 'MP01', 20, 20, 4),
('DK002', 'NCC002', 'DV02', 'Vios', 'MP02', 20, 20, 3),
('DK003', 'NCC003', 'DV03', 'Escapo', 'MP03', 20, 20, 5),
('DK004', 'NCC004', 'DV04', 'Cerado', 'MP04', 20, 20, 7);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `dongxe`
--

CREATE TABLE `dongxe` (
  `dongxe` char(10) NOT NULL,
  `hangxe` char(20) DEFAULT NULL,
  `sochongoi` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `dongxe`
--

INSERT INTO `dongxe` (`dongxe`, `hangxe`, `sochongoi`) VALUES
('Cerato', 'KIA', 7),
('Escape', 'Ford', 5),
('Forte', 'KIA', 5),
('Grand-i10', 'Huyndai', 7),
('Hiace', 'Toyota', 16),
('Starex', 'Huyndai', 7),
('Vios', 'Toyota', 5);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `loaidichvu`
--

CREATE TABLE `loaidichvu` (
  `maloaidv` char(10) NOT NULL,
  `tenloaidv` char(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `loaidichvu`
--

INSERT INTO `loaidichvu` (`maloaidv`, `tenloaidv`) VALUES
('DV01', 'Dịch vụ xe taxi'),
('DV02', 'Dịch vụ xe buýt công'),
('DV03', 'Dịch vụ xe cho thuê');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `mucphi`
--

CREATE TABLE `mucphi` (
  `MAMP` char(10) NOT NULL,
  `dongia` int(11) DEFAULT NULL,
  `mota` char(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `mucphi`
--

INSERT INTO `mucphi` (`MAMP`, `dongia`, `mota`) VALUES
(' MPO1', 10, 'Ap dụng từ 1/2015'),
('MP02', 15, 'Ap dung tu 2/2015'),
('MP03', 20, 'Ap dung từ 1/2010'),
('MP04', 25, 'Ap dụng từ 2/2011');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `nhacungcap`
--

CREATE TABLE `nhacungcap` (
  `MaNhaCC` char(10) NOT NULL,
  `TenNhaCC` char(20) DEFAULT NULL,
  `DiaChi` char(30) DEFAULT NULL,
  `SoDT` varchar(11) DEFAULT NULL,
  `MaSoThue` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `nhacungcap`
--

INSERT INTO `nhacungcap` (`MaNhaCC`, `TenNhaCC`, `DiaChi`, `SoDT`, `MaSoThue`) VALUES
('NCC001', 'Cty TNHH Toàn Pháp', 'Hai Chau', '0511399888', 568941),
('NCC002', 'Cty Cổ phần Đông Du', ' Lien Chieu', '05113999889', 456789),
('NCC003', 'Ông Nguyễn Văn A', 'Hoa Thuan', ' 0511399989', 321456),
('NCC004', ' Cty Cổ Phần Toàn Cầ', ' Hai Chau', ' 0511365894', 513364),
('NCC005', 'Cty TNHH AMA', ' Thanh Khe', ' 0511387546', 546546),
('NCC006', 'Bà Trần Thị Bích Vân', 'Lien Chieu', '05113587469', 524545),
('NCC007', 'Cty TNHH Phan Thành', ' Thanh Khe', '05113987456', 113021),
('NCC008', 'Ông Phan Đình Nam', ' Hoa Thuan', '05113532456', 121230),
('NCC009', 'Tập đoàn Đông Nam Á', ' Lien Chieu', '05113987121', 533654),
('NCC010', 'Cty Cổ phần Rạng đôn', ' Lien Chieu', '05113569654', 187864);

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `dangkycungcap`
--
ALTER TABLE `dangkycungcap`
  ADD PRIMARY KEY (`MaDKCC`);

--
-- Chỉ mục cho bảng `dongxe`
--
ALTER TABLE `dongxe`
  ADD PRIMARY KEY (`dongxe`);

--
-- Chỉ mục cho bảng `loaidichvu`
--
ALTER TABLE `loaidichvu`
  ADD PRIMARY KEY (`maloaidv`);

--
-- Chỉ mục cho bảng `mucphi`
--
ALTER TABLE `mucphi`
  ADD PRIMARY KEY (`MAMP`);

--
-- Chỉ mục cho bảng `nhacungcap`
--
ALTER TABLE `nhacungcap`
  ADD PRIMARY KEY (`MaNhaCC`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
